<div class="mt-6 text-center text-gray-500 text-sm">
<p>Made with 
                <span class="inline-block animate-pulse text-red-500">❤️</span> 
                by <a href="https://github.com/1dev-hridoy">@1dev-hridoy</a>
            </p>
        </div>
    </div>
    <script src="assets/js/main.js"></script>
    </body>
</html>